package example;

import esun.core.utils.ResultUtil;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;


@FeignClient(name = "token",url = "http://127.0.0.1:8884")
@RequestMapping("/esun")
public interface TokenService {
    /**
     * 调用token服务
     * @param token
     * @return
     */
    @RequestMapping(value = "/checkToken",method = RequestMethod.GET)
    ResultUtil checkToken( @RequestParam("token") String token);
    @PostMapping(value = "/token")
    ResultUtil updateToken(@RequestParam("user") String user);
    @GetMapping(value = "/token")
    ResultUtil getToken(@RequestParam("user") String user);


}
